# detecting car > 2024-01-17 4:08pm
https://universe.roboflow.com/entrenamiento-personalizado-de-yolov5-pwy6k/detecting-car-1vjny

Provided by a Roboflow user
License: CC BY 4.0

